const { test, expect } = require("@playwright/test");
const { LoginPage } = require("../pages/LoginPage");

test.describe("Practice Test Automation – Login Page Tests", () => {

    // TC001
    test("TC001 – Valid Login", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("student", "Password123");
        await expect(page).toHaveURL(/.*logged-in-successfully/);
    });

    // TC002
    test("TC002 – Case-Sensitive Password", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("student", "Password123");

        await expect(page).toHaveURL(/.*logged-in-successfully/);
    });

    // TC003
    test("TC003 – Invalid Username", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("wrong", "Password123");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    // TC004
    test("TC004 – Invalid Password", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("student", "wrong");

        await expect(login.errorMsg).toHaveText("Your password is invalid!");
    });

    // TC005 – Both username & password invalid
    test("TC005 – Both Invalid", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("aaa", "bbb");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    // TC006 – Blank username
    test("TC006 – Blank Username", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("", "Password123");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    // TC007 – Blank Password
    test("TC007 – Blank Password", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("student", "");

        await expect(login.errorMsg).toHaveText("Your password is invalid!");
    });

    // TC008 – Both blank
    test("TC008 – Both Blank", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("", "");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    // TC009 – SQL Injection
    test("TC009 – SQL Injection", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("' OR 1=1 --", "Password123");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    // TC010 – HTML Tag Input
    test("TC010 – HTML Tag Input", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("<script>alert(1)</script>", "Password123");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    // TC011 – Very long username
    test("TC011 – Long Username", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();

        await login.login("a".repeat(300), "Password123");
        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    // TC012 – Short password
    test("TC012 – Short Password", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();

        await login.login("student", "123");
        await expect(login.errorMsg).toHaveText("Your password is invalid!");
    });

    // TC013 – Placeholder UI
    test("TC013 – Placeholder UI", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();

        const userPH = await login.username.getAttribute("placeholder");
        const passPH = await login.password.getAttribute("placeholder");

        expect(userPH).toBeNull();   // Because no placeholder exists
        expect(passPH).toBeNull();
    });

    // TC014 – Submit button visibility
    test("TC014 – Submit Button Visible", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();

        await expect(login.loginBtn).toBeVisible();
    });

    // TC015 – Error message UI
    test("TC015 – Error Message UI", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("wrong", "123");

        await expect(login.errorMsg).toBeVisible();
    });

    // TC016 – Password masking
    test("TC016 – Password Masking", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();

        const type = await login.password.getAttribute("type");
        expect(type).toBe("password"); // password masking
    });

    /* ------------------------
       BUG REPORT SUMMARY (Matches PDF)
    ------------------------ */

    test("BUG01 – Generic Error Message", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("wrong", "wrong");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    test("BUG02 – No Eye Icon for Password", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();

        // No eye icon expected → should not exist
        const eyeIcon = page.locator(".show-password");
        await expect(eyeIcon).not.toBeVisible();
    });

    test("BUG03 – No Field Level Validation", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();
        await login.login("", "");

        await expect(login.errorMsg).toHaveText("Your username is invalid!");
    });

    test("BUG04 – No Forgot Password Link", async ({ page }) => {
        const login = new LoginPage(page);
        await login.goto();

        const forgot = page.locator("text=Forgot Password");
        await expect(forgot).toHaveCount(0);
    });

});
