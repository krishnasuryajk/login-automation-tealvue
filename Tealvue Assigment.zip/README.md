# Login Automation – Playwright (JavaScript)

This repository contains automation scripts for 16 login test cases
based on the Practice Test Automation login page.

Tools Used:
- Playwright
- JavaScript
- VS Code
- Chromium & WebKit

All test cases passed as per scenario.
